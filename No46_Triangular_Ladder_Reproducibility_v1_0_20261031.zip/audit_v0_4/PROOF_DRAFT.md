# No.46: Two-part e-unimodality for triangular ladders — revised audit proof v0.3

**Author:** Ryutaro Yonezu — Independent Researcher (AI-assisted working manuscript).
**Status:** Mathematical proof PASS according to Claude's 2026-10-31 v0.2 adversarial audit, **conditional on the explicitly cited Tom Proposition 5.3 and Lemma 3.13** (source wording checked separately by the authoring assistant). Three expository holes were patched in v0.3 *without changing Theorem T*; Claude's 2026-10-31 v0.3 differential audit reported **PASS for all patched sections**. This v0.4 only clarifies a displayed algebraic intermediate step and updates the literature audit/status; *not peer reviewed*. NOVELTY **INCONCLUSIVE**; RELEASE **HOLD**.
**Scope:** Only two-part partitions, not complete e-unimodality.

## 1. Theorem and conventions

Let `G_n=P_n^2` on `[n]`, with edges `{i,j}` exactly when `1<=|i-j|<=2`. In Shareshian–Wachs's notation it is `G_(n,3)`; Tom calls it the triangular ladder `P_(n,2)`. Let `X_G(x;q)` denote the chromatic quasisymmetric function, where an ascent of a proper coloring is an edge `{i,j}` with `i<j` and `kappa(i)<kappa(j)`.

**Theorem T (proposed):** For every `n>=3` and `1<=k<=floor(n/2)`, the polynomial

    c_(n-k,k)(q) = [e_(n-k,k)] X_(G_n)(x;q)

has nonnegative integer coefficients and is palindromic and unimodal in `q`.

**Zero cases:** `c_(2,1)=0` at `(n,k)=(3,1)` and `c_(2,2)=0` at `(4,2)`; these satisfy the assertion trivially. The theorem does **not** claim anything about partitions with 3 or more parts. Set `t=1+q`, `[r]_q=sum_(j=0)^(r-1) q^j`, and `[0]_q=0`.

The formal statement concerns a *proposed result with proof given below*, but novelty relative to all published literature has not been established.

## 2. Imported results from Foster Tom (2025) — source checked

Tom, *A signed e-expansion of the chromatic quasisymmetric function*, **Proposition 5.3, (5.3)–(5.5), printed p.30**, explicitly defines:

    s_k(G) = sum_(T1,T2) q^{inv_G(list(T1)list(T2))},

where the sum is over ordered pairs of decreasing trees covering `[n]`, with `1 in V(T1)` and `|V(T2)|=k`. **There is no `sum_i(r_i-1)` term in (5.3).** This is distinct from the *general forest-triple* weight in his earlier Definition 3.3, (3.4), which *does* have that term. **No assertion is made here as to how that separate term is absorbed:** such an explanation is unnecessary for the present proof, which cites the already established Proposition 5.3 directly.

Set `s(G)=[b_2]_q...[b_n]_q`; here `b_i` is the count of smaller neighbors of `i`. For `G_n`, `s(G_n)=t^{n-2}`. Put `U_(n,j)=[j]_q s_j(G_n)-s(G_n)`.

For `1<=k<n/2`, Tom's (5.5) is precisely

    c_(n-k,k) = [n-k]_q U_(n,k) + [k]_q U_(n,n-k).

**Equal-parts exception:** If `n=2k`, Tom explicitly says to use just *one* of these two equal terms:

    c_(k,k)=[k]_q U_(2k,k).

Source: https://doi.org/10.5070/C65265413 ; printed p.30 / PDF page 30.

## 3. Complete derivation of the bivariate generating function from (5.3)

Let `A=V(T1)` and `B=V(T2)`; `1 in A`, `B != empty`, and both induced sets admit decreasing spanning trees. By Tom's Lemma 3.13 (applied separately to `G[A]`, `G[B]`), summing weights of decreasing trees on a *fixed* vertex subset `S` gives

    T(S)=prod_(i in S, i>min S) [b_i(S)]_q,

where `b_i(S)=#{j in S: i-2<=j<i}` **counts adjacent smaller-labelled vertices inside the subset S** (the graph here contains edges only at distances 1 and 2). If some factor has `b_i(S)=0`, the weight is zero. The cross-block inversion count depends only on the A/B placement, namely

    cross(A,B)=#{(b,a): b in B, a in A, b<a<=b+2}.

Thus `(5.3)` is the weighted sum over A/B assignments, with factor `q^{cross(A,B)} T(A)T(B)` and `z` counting B vertices.

Process vertices from 1 through n. Before the first B, we have a run of A vertices. The **first B** is at position j>=2:

* `j=2` has weight `z*x^2`, ending in the two-symbol state `AB`.
* `j>=3` has weight `z*x^j*t^{j-3}`, also ending in state `AB` (the A vertices from 3 through `j-1` each have two smaller A neighbors).

The total initial weight is therefore

    I(x,z)=z*x^2 + z*x^3/(1-t*x)=z*x^2*(1-q*x)/(1-t*x).

After the first B, only the previous two A/B symbols matter. Order the states `AA,AB,BA,BB`. The transition matrix `M`, with entry `(old,new)` equal to the weight for appending the next vertex, is

                   AA   AB   BA   BB
      AA           t    0    0    0
      AB           0    0    q    z
      BA           q    z    0    0
      BB           0    0    0   z*t

Explanation: appending A requires at least one A among the preceding two (and contributes `[count A]_q`), plus `q^{count B}` for newly completed cross-block inversions; appending B requires a preceding B (except at its first appearance) and contributes `z*[count B]_q`. Transitions with no preceding same-group vertex are impossible, because then that vertex cannot be part of a decreasing tree on its assigned subset.

Since every appended vertex supplies one factor `x`, and the initial state is `AB`, the exact generating function is

    S(x,z;q)=sum_(n>=2) sum_(1<=j<n) s_j(G_n) x^n z^j
            = I(x,z) * e_AB^T * (Id-x*M)^(-1) * 1.

A direct 4x4 inverse calculation yields

    S= z*x^2*(1-q*x)/((1-t*x)*(1-q*z*x^2))
       * ((1-x-q*x^2)/(1-t*x) + x*z/(1-t*z*x)).       (GF)

`verify_transfer.py` checks this **rational identity symbolically**, independently from the finite enumerators. The preceding local-weight argument is the proof from Tom's (5.3); the script alone would not prove the combinatorial interpretation.

## 4. Extracted formulas for s_k and s_(n-k)

Write `n=2k+d`, `k>=1`, `d>=0`, with `C_1=0` and for `k>=2`:

    C_k(q)=sum_(a=0)^(k-2) q^a t^(2k-3-2a).

We give the formal extraction explicitly. Split the displayed generating function (GF) using
`(1-q*x)*(1-x-q*x^2)=1-t*x+q^2*x^3`:

    S = S_I + S_II,
    S_I  = z*x^2*(1-t*x+q^2*x^3) / ((1-t*x)^2*(1-q*z*x^2)),
    S_II = z^2*x^3*(1-q*x) / ((1-t*x)*(1-t*z*x)*(1-q*z*x^2)).

The two elementary coefficient identities are

    [x^N] (1-t*x+q^2*x^3)/(1-t*x)^2
      = t^N + 1_(N>=3) (N-2)*q^2*t^(N-3),          N>=0,

    [x^J] (1-q*x)/(1-t*x)
      = 1 if J=0, and t^(J-1) if J>=1.             (t-q=1)

For `s_k` at `n=2k+d`, `z^k` in `S_I` forces the factor
`q^(k-1)*x^(2k)` and the first identity with `N=d` gives
`q^(k-1)*t^d + 1_(d>=3)(d-2)*q^(k+1)*t^(d-3)`.

In `S_II`, expand `1/(1-q*z*x^2)` with index `r`, then
`1/(1-t*z*x)` with index `s`. The `z^k` coefficient requires
`r+s=k-2`. The remaining exponent in `(1-q*x)/(1-t*x)` is
`J=k+d-1-r>=d+1>=1`. Hence its sum is

    sum_(r=0)^(k-2) q^r * t^(k-2-r) * t^(k+d-2-r)
      = sum_(r=0)^(k-2) q^r*t^(n-4-2r).

Combining gives, for all `d>=0`,

    s_k(G_(2k+d)) = q^(k-1)*t^d
                      + sum_(r=0)^(k-2) q^r*t^(n-4-2r)
                      + 1_(d>=3) (d-2)*q^(k+1)*t^(d-3).      (E1)

Equivalently its middle term is `t^(d-1)*C_k` (for `d=0`, the
explicit sum is used so no negative-power expression is needed).

For `s_(n-k)`, assume `d>=1`, so `j=n-k=k+d`. No `S_I` term
contributes because its smallest `x` degree at `z^j` is `2j>n`.
In `S_II`, `r+s=j-2=k+d-2` and the remaining exponent is
`J=k-1-r`. For `0<=r<=k-2`, `J>=1`, giving
`sum_(r=0)^(k-2)q^r*t^(n-4-2r)`. The boundary `r=k-1`
has `J=0` and contributes `q^(k-1)*t^(d-1)`. Therefore

    s_(n-k)(G_n) = t^(d-1) * (q^(k-1)+C_k),       d>=1.      (E2)

The empty-sum convention handles `k=1`. This derivation proves
(E1),(E2) for all indicated parameters; finite checks are not being
used in place of formal coefficient extraction. These identities were
also reported as independently checked by Claude via original-definition
DP for `n<=40` (779 instances; see `CLAUDE_REPORT_INTEGRATION.md`).

A geometric-series evaluation of C gives the useful exact polynomial identity

    [3]_q C_k=t^(2k-1)-q^(k-1)t,    k>=2.                     (E3)

Indeed `C_k = t^(2k-3)*sum_(a=0)^(k-2) (q/t^2)^a` and `t^2-q=[3]_q`.

## 5. Diagonal case and small-index positivity (identities A and B)

Define `D_k=U_(2k,k)`. **From (E1), rather than as a definition**, direct substitution at `d=0` gives `D_1=D_2=0` (use the empty sum for `k=1` and `C_2=t` for `k=2`). For `k>=3`, (E1) at `d=0` gives `s_k=q^(k-1)+C_k/t`, and (E3) yields

    [3]_q D_k = q^3[k-3]_q t^(2k-2)+q^k t[k]_q,   k>=3.     (A1)

The division by `[3]_q` is exact because the left side is a polynomial by its original definition. Summing (A1) in `k` using geometric series gives

    sum_(k>=3) D_k z^(k-3)
      =q^3*t*(1+q*t*z)/
       ((1-q*z)(1-q^2*z)(1-t^2*z)(1-q*t^2*z)).               (A2)

For clarity, coefficient extraction of the right side of (A2) explicitly gives

    D_k=q^3*t*sum_(a+b=k-3) q^a[a+1]_q t^(2b)[b+1]_q
        +q^4*t^2*sum_(a+b=k-4) q^a[a+1]_q t^(2b)[b+1]_q,    (A3)

with empty sums zero. `verify_transfer.py` symbolically sums the **closed** (A1) formula over all `k>=3` and checks its equality to the **positive-sum** (A2) rational generating function, without finite truncation. `check_claims.py` supplies finite checks only.

Each nonzero summand in (A3) has nonnegative coefficients and is symmetric unimodal around `(3k-2)/2`. Therefore each `D_k` has the same property.

Finally, from (E1) at general d, 

    U_(n,k)=t^d D_k + 1_(d>=3)(d-2)q^(k+1)[k]_q t^(d-3).     (B)

Both summands (when nonzero) have center `(n+k-2)/2`. Thus `U_(n,k)` is nonnegative, palindromic and unimodal for every `k<=n/2`.

## 6. Large-index side (identity C)

For `n=2k+d`, `d>=1`, E2 gives

    U_(n,n-k)=t^(d-1)([k+d]_q(q^(k-1)+C_k)-t^(2k-1)).

For `k>=2`, use (E3), `[k+d]_q=[3]_q+q^3[k+d-3]_q`, and
`t=1+q`. The intermediate algebra is (all brackets are q-integers):

    [3]_q*(q^(k-1)+C_k) - t^(2k-1)
       = q^(k-1)*([3]_q-t) = q^(k+1),

    q^3*[k+d-3]_q*(q^(k-1)+C_k)
       = q^3*[k+d-3]_q*C_k + q^(k+2)*[k+d-3]_q,

    [k+d]_q*(q^(k-1)+C_k) - t^(2k-1)
       = q^3*[k+d-3]_q*C_k
         + q^(k+1)*(1+q*[k+d-3]_q),

    1+q*[m]_q = [m+1]_q.

Thus

    U_(n,n-k)=t^(d-1) ( q^3*[k+d-3]_q*C_k
                       + q^(k+1)*[k+d-2]_q ),   k>=2.        (C)

For `k=1`, directly from E2:

    U_(n,n-1)=q^2[d-1]_q t^(d-1),  n=2+d, d>=1.              (C1)

Each summand in `C_k` has common center `(2k-3)/2`. The two nonzero terms in (C) have common center *before* multiplication by `t^(d-1)` equal to `(3k+d-1)/2`; after multiplication the center is `(2n-k-2)/2`. The same result holds for (C1). Products and sums preserve nonnegative symmetry/unimodality when the centers align. Thus `U_(n,n-k)` is nonnegative, symmetric and unimodal.

## 7. Completion of theorem T

For `n>2k`, apply Tom's (5.5). In the first term `[n-k]_q U_(n,k)` the center is

    (n-k-1)/2 + (n+k-2)/2 = (2n-3)/2.

In the second term `[k]_q U_(n,n-k)` the center is

    (k-1)/2 + (2n-k-2)/2 = (2n-3)/2.

Thus their sum is nonnegative, palindromic and unimodal. For `n=2k`, Tom's *one-term* formula `[k]_q D_k` has this same center. The two zero cases `n=3,k=1` and `n=4,k=2` are covered separately. This concludes the mathematical derivation **assuming the explicitly cited Tom Proposition 5.3 and Lemma 3.13**. Whether it constitutes a previously unpublished theorem is a **separate** prior-art question and remains unresolved.

## 8. Limits and reproducibility statement

- This proves the *two-part* coefficient claim, NOT full e-unimodality for `G_n`.
- Finite tests in the original packet: `n<=8` direct colorings (15 coefficients), `n<=11` decreasing forests (55 cases), `n<=32` GF/formula (495 cases). They do not imply the universal theorem by themselves.
- Claude's independent report provided by user: independent coloring to `n<=13` (41 coefficients); generating-function/tree checks via a separate DP to `n<=40` (779 instances); closed-form properties `n<=120` (3597 coefficients). These are *reported* results; the separate `No46_Claude_Audit_Scripts.zip` was not supplied in this session and thus is NOT bundled or re-executed here.
- `check_claims.py`, `check_gf.py`, and `verify.py` share code; they are **not** independent implementations. The original `check_coloring_basis.py` is the independent colorings/basis-change implementation.
- Mathematical audit status: **PASS (Claude v0.2 proof audit conditional on Tom Proposition 5.3 / Lemma 3.13, source subsequently checked; v0.3 differential corrections PASS per Claude 2026-10-31 report)**. v0.4 adds one displayed intermediate algebraic equality but no new claim. Novelty **INCONCLUSIVE**. Publication **HOLD** pending more complete literature coverage, particularly the inaccessible full SIAM 2019 Cho–Huh theorem list.
