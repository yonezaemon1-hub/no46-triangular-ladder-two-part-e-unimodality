#!/usr/bin/env python3
"""Audit tests of claimed identities (does not assert an algebraic proof)."""
from verify import add,sub,mul,shift,powpoly,qint,fmt,sk,U,c,sp

def sumterms(terms):
 r={}
 for a in terms:r=add(r,a)
 return r

def C(k):
 assert k>=2
 return sumterms([shift(powpoly({0:1,1:1},2*k-3-2*a),a) for a in range(k-1)])

def B(k):return add(C(k),{k-1:1})

def D_rational(k):
 assert k>=3
 from verify import old_D
 q,r=old_D(k);assert r=={},r
 return q

def D_gf(k):
 # Explicit coefficient of z^(k-3) in claimed generating function:
 # q^3 t (1 + q t z) * sum_a q^a[a+1]_q z^a * sum_b t^(2b)[b+1]_q z^b
 assert k>=3
 N=k-3
 out={}
 for eps in (0,1):
  if N<eps:continue
  for a in range(N-eps+1):
   b=N-eps-a
   term=mul(shift(qint(a+1),3+eps+a),powpoly({0:1,1:1},1+eps+2*b))
   term=mul(term,qint(b+1))
   out=add(out,term)
 return out

def small_U(k,d):
 assert k>=1 and d>=0
 if k<=2: out={}
 else:out=mul(powpoly({0:1,1:1},d),D_gf(k))
 if d>=3:
  correction=shift(mul(qint(k),powpoly({0:1,1:1},d-3)),k+1)
  out=add(out,{a:(d-2)*v for a,v in correction.items()})
 return out

def large_U(k,d):
 assert k>=1 and d>=1
 t=powpoly({0:1,1:1},d-1)
 if k==1:return shift(mul(qint(d-1),t),2)
 return mul(t,add(shift(mul(qint(k+d-3),C(k)),3),shift(qint(k+d-2),k+1)))

def is_unimodal(poly):
 arr=[poly.get(i,0) for i in range(max(poly,default=0)+1)]
 j=max(range(len(arr)),key=lambda i:arr[i]);return arr[:j+1]==sorted(arr[:j+1]) and arr[j:]==sorted(arr[j:],reverse=True)

def is_palindromic(poly):
 if not poly:return True
 lo,hi=min(poly),max(poly)
 return all(poly.get(lo+i,0)==poly.get(hi-i,0) for i in range((hi-lo)//2+1))

checks=[]
def check(tag,ok,details=''):
 checks.append((tag,ok,details))
 if not ok:print('FAIL',tag,details)

if __name__=="__main__":
 for k in range(3,30):
  check('D-gf-versus-rational k='+str(k),D_gf(k)==D_rational(k))
  check('D nonneg palindrome unimodal '+str(k),is_unimodal(D_gf(k)) and is_palindromic(D_gf(k)) and all(v>=0 for v in D_gf(k).values()))
 
 for n in range(3,11):
  for k in range(1,n//2+1):
   d=n-2*k
   check('U-small n='+str(n)+' k='+str(k),small_U(k,d)==U(n,k), f"lhs={fmt(U(n,k))}; rhs={fmt(small_U(k,d))}")
   if d>=1:
    check('U-large n='+str(n)+' k='+str(k),large_U(k,d)==U(n,n-k), f"lhs={fmt(U(n,n-k))}; rhs={fmt(large_U(k,d))}")
   check('c positivity symmetry unimodality '+str(n)+' '+str(k),all(v>=0 for v in c(n,k).values()) and is_unimodal(c(n,k)) and is_palindromic(c(n,k)))
 
 # Graph e-coeff at n=8, k=3 direct forest formula
 expected={3:2,4:12,5:30,6:45,7:45,8:30,9:12,10:2}
 check('previous stated c_(5,3) n=8',c(8,3)==expected)
 # n=8 k=4: known expected q^3 t^3(1+q²)(1+4q+q²)
 expected44=shift(mul(mul(powpoly({0:1,1:1},3),{0:1,2:1}),{0:1,1:4,2:1}),3)
 check('previous stated c_(4,4) n=8',c(8,4)==expected44, f'actual {fmt(c(8,4))} expected {fmt(expected44)}')
 
 passed=sum(x[1] for x in checks)
 print(f'CHECKS: {passed}/{len(checks)} PASS')
 assert passed==len(checks),'CLAIMED IDENTITIES INVALID'
