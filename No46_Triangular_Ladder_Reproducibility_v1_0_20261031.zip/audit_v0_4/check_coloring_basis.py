#!/usr/bin/env python3
"""Direct proper colorings -> monomial coefficients -> exact e-basis inversion.
Entirely independent of Tom's tree-forest enumeration and proposed GF.
Python standard library only, intentionally restricted to small n.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from functools import lru_cache
from verify import c as forest_coefficient

def partitions(n, biggest=None):
 if n==0:
  yield ()
 else:
  biggest = n if biggest is None else min(biggest,n)
  for top in range(biggest,0,-1):
   for tail in partitions(n-top,top):yield (top,)+tail

def color_words(counts):
 n=sum(counts);r=len(counts)
 def rec(current,cnt):
  if len(current)==n:
   yield tuple(current);return
  for j in range(r):
   if cnt[j]:
    cnt[j]-=1;current.append(j)
    yield from rec(current,cnt)
    current.pop();cnt[j]+=1
 yield from rec([],list(counts))

def monomial_weight(mu):
 n=sum(mu)
 edges=[(i,j) for i in range(n) for j in range(i+1,min(n,i+3))]
 o=Counter()
 for w in color_words(mu):
  if any(w[i]==w[j] for i,j in edges):continue
  o[sum(w[i]<w[j] for i,j in edges)]+=1
 return dict(o)

@lru_cache(None)
def e_monomial_coeff(lam,mu):
 r=len(mu);choices=[list(combinations(range(r),part)) for part in lam]
 states={tuple(0 for _ in range(r)):1}
 for cs in choices:
  nxt={}
  for used,ways in states.items():
   for subset in cs:
    used2=list(used)
    for j in subset:used2[j]+=1
    u=tuple(used2)
    if all(u[j]<=mu[j] for j in range(r)):
     nxt[u]=nxt.get(u,0)+ways
  states=nxt
 return states.get(mu,0)

def solve(A,y):
 n=len(y)
 rows=[[Fraction(A[i][j]) for j in range(n)]+[Fraction(y[i])] for i in range(n)]
 for col in range(n):
  pivot=next((i for i in range(col,n) if rows[i][col]),None)
  assert pivot is not None,'basis matrix singular'
  rows[pivot],rows[col]=rows[col],rows[pivot]
  p=rows[col][col];rows[col]=[x/p for x in rows[col]]
  for i in range(n):
   if i!=col and rows[i][col]:
    m=rows[i][col];rows[i]=[x-m*z for x,z in zip(rows[i],rows[col])]
 return [row[-1] for row in rows]

def independent_two_part_coeff(n):
 ps=list(partitions(n));a=[[e_monomial_coeff(lam,mu) for lam in ps] for mu in ps]
 mon=[monomial_weight(mu) for mu in ps]
 maxq=2*n-3
 res=[{} for _ in ps]
 for j in range(maxq+1):
  b=solve(a,[m.get(j,0) for m in mon])
  for ix,v in enumerate(b):
   assert v.denominator==1,(n,ps[ix],j,v)
   if v:res[ix][j]=int(v)
 return {ps[ix]:v for ix,v in enumerate(res)}

if __name__=='__main__':
 ct=0
 for n in range(3,9):
  e=independent_two_part_coeff(n)
  for k in range(1,n//2+1):
   lam=(n-k,k)
   candidate=forest_coefficient(n,k)
   assert e[lam]==candidate,(n,lam,e[lam],candidate)
   ct+=1
  print(f'n={n} two-part coefficients PASS')
 print(f'DIRECT COLORING -> EXACT E BASIS: {ct}/{ct} PASS')
