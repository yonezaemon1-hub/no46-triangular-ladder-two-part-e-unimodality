# No.46 文献照合追加記録（2026-10-31）

**判定: 既知の完全一致は未確認。ただし新規性は INCONCLUSIVE、公開 HOLD。**

## 1. Cho–Huh (2018会議版 / 2019 SIAM版)

- 2018会議版一次資料（12頁）：https://www.mat.univie.ac.at/~slc/wpapers/FPSAC2018/59-Cho-Huh.pdf
- PDF掲載頁10の Proposition 4.2：仮定 `m_1=...=m_s=r`, `m_(s+1)=n`。
- PDF掲載頁11の Proposition 4.5：仮定 `m_1=r`, `m_2=...=m_s=n-1`, `m_(s+1)=n`。
- 三角ラダーの `m_i=min(i+2,n)` は `n>=6` で双方の仮定を満たさない。`n>=6` に関して**この2命題から主定理 T が直ちに出るわけではない**。
- 2019 SIAM正式版：https://doi.org/10.1137/18M1216201 (Vol.33 Issue4 pp.2286–2315)。出版社の要旨は bounce=2 と一部の bounce=3、および特定の部分族の単峰性のみを明記する。**正式版の定理全文にアクセスできなかったため、正式版の完全非包含は未確認。** 会議版の命題番号と混同しない。

## 2. Foster Tom (2025)

- 本文：https://escholarship.org/content/qt9dc0v7wb/qt9dc0v7wb_noSplash_28ede5a36d36f74b24d311c99b18bfbc.pdf
- §5 printed pp.29–31, Problem 5.2 は三角ラダーの完全な e-unimodality を課題として提示。Prop 5.3 (5.3)-(5.5) は本研究の引用基盤。今回の主定理 T は**全係数ではなく2部分係数のみ**。
- 同論文 Cor. 4.20 はK-chain系の単峰性であり、三角ラダーを同論文が直接解決したとは述べていない。

## 3. Sagan–Tom (2026)

- 全文：https://alco.centre-mersenne.org/item/10.5802/alco.468.pdf
- 定理・節の内容：e基底での非零制限、いくつかの形の非負性、`e_n` の表現、§4 Conjecture 4.2（e-log-concavity）。
- 本文中に `P_n^2` の全2部分係数 `q`-単峰性を直接述べた一般定理は確認できなかった。ただし全数学文献の非重複を保証しない。

## 4. 2025–26年の近接研究との識別

- 2026-10-27更新の文献カタログ：https://www.symmetricfunctions.com/chromaticEexpansion.htm
- 掲載されている2025–26年の系統（twinned paths/cycles、cycle-chord、clocks、conjoined graphs、clique gluing、adjacent cycle-chains、Hikitaの精密化など）を**探索語の展開・関連分野の把握に使用**。全論文の全文/全定理を査読したわけではない。
- 2026年OpenAIの自然単位区間グラフ全体の e-positivity は `c_lambda(q)∈N[q]` の非負性であり、No.46が対象とする単峰性とは別。
- 2025年Tomの有向性を含む `q` 版と、2018年Dahlbergの `q=1` 結果を混同しない。

## 5. 残留リスクと判断

1. 2019 SIAM Cho–Huh正式版の全文定理群（2018会議版とは区別）。
2. 新規性は検索の不在証明ではない。未索引のプレプリントや、別名の同値定理があり得る。
3. No.46の一般定理 T は Claude独立監査報告で数学PASSだが、最終的な人的査読は未実施。

**NOVELTY INCONCLUSIVE / RELEASE HOLD のまま。**
