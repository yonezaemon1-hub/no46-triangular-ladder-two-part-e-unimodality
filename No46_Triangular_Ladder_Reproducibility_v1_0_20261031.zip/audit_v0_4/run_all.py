#!/usr/bin/env python3
"""Run all audit scripts in order; stop on first failure."""
import subprocess
import sys
from pathlib import Path
root=Path(__file__).resolve().parent
for name in ('check_hashes.py','check_claims.py','check_gf.py','check_coloring_basis.py','verify_transfer.py','verify_extraction.py'):
 print(f'=== {name} ===',flush=True)
 subprocess.run([sys.executable,str(root/name)],cwd=root,check=True)
print('RUN_ALL: PASS (finite + symbolic identity checks; proof and novelty audits remain required)')
