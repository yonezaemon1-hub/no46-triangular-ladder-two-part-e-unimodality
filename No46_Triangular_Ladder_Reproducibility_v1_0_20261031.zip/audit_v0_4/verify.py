#!/usr/bin/env python3
"""Independent small-n enumerator for Tom 2025 Prop 5.3 (stdlib only)."""
from itertools import product
from collections import Counter
from functools import lru_cache

def add(a,b):
 c=Counter(a);c.update(b);return +c

def sub(a,b):
 c=Counter(a);c.subtract(b);return {e:v for e,v in c.items() if v}

def mul(a,b):
 o=Counter()
 for i,x in a.items():
  for j,y in b.items():o[i+j]+=x*y
 return +o

def shift(a,s):return {i+s:v for i,v in a.items()}
def powpoly(a,n):
 b={0:1}
 for _ in range(n):b=mul(b,a)
 return b

def qint(k):return {i:1 for i in range(k)}

def fmt(a):return ','.join(str(a.get(i,0)) for i in range(max(a, default=-1)+1))

@lru_cache(None)
def trees_of_set(S):
 """Enumerates decreasing trees for vertex-set S as edge lists plus tree lists.
 Each vertex except max has exactly one larger parent separated by 1 or 2.
 """
 S=tuple(S)
 if not S:return []
 vertices=S[:-1]
 choices=[[p for p in S if p>v and p-v<=2] for v in vertices]
 if any(not x for x in choices):return []
 out=[]
 for pars in product(*choices):
  edges=list(zip(vertices,pars));seen={S[0]};order=[S[0]]
  while len(order)<len(S):
   unread=[v for v in S if v not in seen and any((v==x and y in seen) or (v==y and x in seen) for x,y in edges)]
   assert unread,(S,edges,order)
   v=min(unread);seen.add(v);order.append(v)
  out.append(tuple(order))
 return out

def inv_G(word):
 ans=0
 for i in range(len(word)):
  for j in range(i+1,len(word)):
   if word[i]>word[j] and word[i]-word[j]<=2:ans+=1
 return ans

def sk(n,k):
 vertices=list(range(1,n+1));res=Counter()
 for mask in range(1<<(n-1)):
  B=tuple(v for v in range(2,n+1) if mask>>(v-2)&1)
  if len(B)!=k:continue
  A=tuple(v for v in vertices if v not in B)
  for a in trees_of_set(A):
   for b in trees_of_set(B):res[inv_G(a+b)]+=1
 return +res

def sp(n):return powpoly({0:1,1:1},n-2) if n>=2 else {0:1}

def U(n,k):return sub(mul(qint(k),sk(n,k)),sp(n))

def c(n,k):
 assert 1<=k<=n//2
 left=mul(qint(n-k),U(n,k))
 if n==2*k:return left
 return add(left,mul(qint(k),U(n,n-k)))

def old_D(k):
 # previous assertion: Dk=(q^3[k-3]_q t^(2k-2)+q^k t[k]_q)/(1+q+q^2)
 # need exact division, integer polynomial
 A=add(shift(mul(qint(k-3),powpoly({0:1,1:1},2*k-2)),3),shift(mul({0:1,1:1},qint(k)),k))
 Q={};R=dict(A)
 while R:
  j=max(R);v=R[j]
  if j<2:break
  Q[j-2]=v
  for d in (0,1,2):
   p=j-2+d;R[p]=R.get(p,0)-v
   if R[p]==0:del R[p]
 return Q,R

if __name__=='__main__':
 for n in range(3,10):
  print('n',n,'s(G)',fmt(sp(n)))
  for k in range(1,n):
   print(' k',k,'s_k',fmt(sk(n,k)),'U',fmt(U(n,k)))
  for k in range(1,n//2+1):print(' c',n-k,k,fmt(c(n,k)))
 for k in range(3,8):
  q,r=old_D(k)
  print('D',k,'direct',fmt(U(2*k,k)), 'old-rational',fmt(q),'rem',r,'equal?',U(2*k,k)==q)
