#!/usr/bin/env python3
"""Exact coefficient extraction of the *claimed* rational bivariate GF.
This cross-checks the claim against independently enumerated Tom forests.
It is NOT a derivation of the GF from the combinatorial definition.
"""
from verify import sk, qint, powpoly, fmt
from check_claims import small_U, large_U, D_gf

def add(*terms):
 o={}
 for t in terms:
  for i,v in t.items():o[i]=o.get(i,0)+v
 return {i:v for i,v in o.items() if v}

def scale(A,c):return {i:v*c for i,v in A.items()}
def shift(A,d):return {i+d:v for i,v in A.items()}

def gf_sk(n,k):
 """Coeff [x^n z^k] in S = z x²(1-tx+q²x³)/((1-tx)²(1-qzx²))
 + z²x³(1-qx)/((1-tx)(1-qzx²)(1-tzx)), t=1+q.
 """
 t={0:1,1:1}
 o={}
 if k>=1:
  r=k-1;N=n-2-2*r
  for j,P in [(0,{0:1}),(1,{0:-1,1:-1}),(3,{2:1})]:
   if N-j>=0:o=add(o,shift(scale(powpoly(t,N-j),N-j+1),r+j*0) if j==0 else shift(scale(__mul(P,powpoly(t,N-j)),N-j+1),r))
 if k>=2:
  for r in range(k-1):
   b=k-2-r;N=n-3-2*r-b
   if N>=0:o=add(o,shift(powpoly(t,N+b),r))
   if N-1>=0:o=add(o,shift(scale(powpoly(t,N-1+b),-1),r+1))
 return o

def __mul(A,B):
 o={}
 for i,v in A.items():
  for j,w in B.items():o[i+j]=o.get(i+j,0)+v*w
 return o

if __name__=='__main__':
 cnt=0
 for n in range(2,12):
  for k in range(1,n):
   a=gf_sk(n,k);b=sk(n,k)
   assert a==b, f'n={n} k={k} GF={fmt(a)} enumeration={fmt(b)}'
   cnt+=1
 print(f'GF-vs-independent-forest: {cnt}/{cnt} PASS (n<=11)')
 # Stronger cross-check over larger n, using formulas from candidate draft vs GF
 M=32
 cnt=0
 for n in range(3,M+1):
  for k in range(1,n//2+1):
   sk_g=gf_sk(n,k);sk_other=gf_sk(n,n-k)
   t=powpoly({0:1,1:1},n-2)
   def diff(a,b):return add(a,scale(b,-1))
   def product(a,b):return __mul(a,b)
   u_g=diff(product(sk_g,qint(k)),t)
   u_other=diff(product(sk_other,qint(n-k)),t)
   expected=small_U(k,n-2*k)
   assert u_g==expected,(n,k,'small',fmt(u_g),fmt(expected))
   cnt+=1
   if n>2*k:
    expected2=large_U(k,n-2*k)
    assert u_other==expected2,(n,k,'large',fmt(u_other),fmt(expected2))
    cnt+=1
 print(f'GF-vs-candidate-U: {cnt}/{cnt} PASS (n<=32)')
