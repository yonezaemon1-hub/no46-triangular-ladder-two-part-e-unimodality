# No.46 prior-art decision log — revised v0.3, 2026-10-31

**NOVELTY: INCONCLUSIVE / RELEASE: HOLD.** This is an audit of direct known-theorem containment, not a claim of priority.

## A. Foster Tom (2025), verified primary source
- *A signed e-expansion of the chromatic quasisymmetric function*, Combinatorial Theory 5(2) #11.
- https://doi.org/10.5070/C65265413 ; full PDF https://escholarship.org/content/qt9dc0v7wb/qt9dc0v7wb_noSplash_28ede5a36d36f74b24d311c99b18bfbc.pdf
- Printed p.30, Proposition 5.3 (5.3) explicitly defines `s_k` **without the `r_i-1` term**; (5.4)-(5.5) and the `n=2k` single-term exception match this packet. Lemma 3.13 provides decreasing tree sum; Example 3.6 provides `s(G)`.
- Problem 5.2 asks for full e-unimodality of the triangular ladder — stronger than the present two-part-only claim.

## B. Cho–Huh (2019): theorem containment remains PARTIAL (rechecked 2026-10-31)
- Soojin Cho and JiSun Huh, *On e-Positivity and e-Unimodality of Chromatic Quasi-symmetric Functions*, SIAM J. Discrete Math. 33(4), 2286–2315; DOI https://doi.org/10.1137/18M1216201
- Verified publisher abstract: e-positivity for bounce number 2 and some bounce number 3 cases; e-unimodality for some special subclasses.
- For `G_n=P_n^2` the associated Hessenberg function is `h_n(i)=min(i+2,n)`. By the standard definition `x_1=h_n(1)`, `x_(j+1)=h_n(x_j+1)` until n, giving `x_j=min(3j,n)` and hence **bounce number `b(G_n)=ceil(n/3)`**. The algorithm is stated in Cho–Hong (2022), Definition 13, https://www.combinatorics.org/ojs/index.php/eljc/article/download/v29i2p19/pdf/
- Therefore **for n>=10**, `b(G_n)>=4`. Cho–Huh's published abstract's bounce-2 and bounce-3 claims do not contain the unrestricted family `G_n` for all n. This *rules out simple global containment by those stated families*.
- IMPORTANT LIMITATION: Full Cho–Huh theorem list has **not** been line-by-line inspected (the publisher page only provided abstract), and another theorem/formula may conceivably imply two-part unimodality without requiring bounce<=3. Thus **no unconditional no-overlap conclusion**.


### Directly inspected precursor (2018 conference version)
The 12-page preprint by the **same authors**, *Séminaire Lotharingien de Combinatoire* 80B (2018), Article 59, is directly accessible and was inspected at the theorem/formula level:
https://www.mat.univie.ac.at/~slc/wpapers/FPSAC2018/59-Cho-Huh.pdf
- Proposition 4.2: the hypothesis is `m_1=...=m_s=r` and `m_(s+1)=n`, with `1<=s<=r<=n-1`; it establishes full e-unimodality in that special family.
- Proposition 4.5: the hypothesis is `m_1=r`, `m_2=...=m_s=n-1`, `m_(s+1)=n`, with `2<=s<=r<=n-2`; another special family.
- On `G_n=P_n^2`, the Hessenberg sequence is `m_i=min(i+2,n)`. For `n>=6`, this has a strictly increasing prefix `3,4,5,6,...`, hence neither above special-family hypothesis holds: in Proposition 4.2, any `s>=2` fails the constant initial block, and `s=1` requires `m_2=n` (false for `n>=6`); in Proposition 4.5, `m_2=n-1` fails for `n>=6`.
- IMPORTANT: these are **2018 conference-version proposition numbers**, NOT necessarily the final SIAM 2019 theorem numbers. Do not conflate them. The full **2019 expanded** published article has **not** yet been directly inspected here. The 2018 result has now been re-inspected visually on PDF pages 10–11: neither proposition covers the entire `P_n^2` family for `n>=6`. This is direct noncontainment for *these two propositions only*, not a complete novelty clearance of the SIAM version.

## C. Dahlberg (2018/2019), q=1 only
- Samantha Dahlberg, *Triangular Ladders P_(d,2) are e-positive*, arXiv:1811.04885; https://arxiv.org/abs/1811.04885
- Proves the ordinary chromatic symmetric function's e-positivity at `q=1`; does not itself establish q-unimodality.

## D. Shareshian–Wachs (2016)
- *Chromatic quasisymmetric functions*, Adv. Math. 295, 497–551; DOI 10.1016/j.aim.2015.12.018.
- Our `G_n` has edges at distances 1 and 2, and is `G_(n,3)` in their notation, not their path `G_(n,2)`.

## E. Sagan–Tom (2026)
- Bruce E. Sagan and Foster Tom, *Chromatic symmetric functions and change of basis*, Algebraic Combinatorics 9(1); DOI https://doi.org/10.5802/alco.468
- The **full published 2026 PDF was directly inspected** (Algebraic Combinatorics 9(1), pp. 307–325). In particular, Introduction and §2 establish support/nonvanishing restrictions and nonnegativity for certain coefficient shapes, §3 handles `e_n`, and §4.2 (the authors' numbering) *conjectures* e-log-concavity for general natural unit interval graphs. The inspected statements do **not** contain a theorem asserting q-unimodality for **all two-part coefficients of `P_n^2`**. This is a theorem-level assessment of this specified publication, not a guarantee that no equivalent result is known elsewhere. Official primary PDF: https://alco.centre-mersenne.org/item/10.5802/alco.468.pdf

## F. Later work / caution
- Shiyun Wang, *e-positivity of chromatic quasisymmetric functions of bounce number three via the inverse Kostka matrix*, 2026 preprint arXiv:2210.07567 (updated 2026); topic concerns bounce number 3 e-positivity, not a verified all-n two-part q-unimodality result.
- Hikita (2024), `q=1` Stanley–Stembridge, not a q-unimodality theorem.

## Required final novelty action
Obtain the complete **2019 SIAM extended** Cho–Huh theorem/proof or author manuscript (the 2018 conference version HAS been inspected) and test the *final* hypotheses, including any two-part coefficient formulas; compare against the present `P_n^2, n>=10` result. A targeted 2025–2026 survey and primary-paper search was undertaken (details in `LITERATURE_AUDIT_20261031_JA.md`); it found no directly matching all-n two-part `q`-unimodality result, but this is not an exhaustive proof of originality. Until the SIAM 2019 full theorem list and any unindexed work are cleared, keep NOVELTY INCONCLUSIVE and RELEASE HOLD.
