#!/usr/bin/env python3
"""Independent symbolic GF split + bounded coefficient-extraction regression.
The finite test is not a proof of universal E1/E2; see PROOF_DRAFT §4.
"""
import sympy as s
x,z,q=s.symbols('x z q')
t=1+q
S=(z*x**2*(1-q*x)/((1-t*x)*(1-q*z*x**2)))*((1-x-q*x**2)/(1-t*x)+x*z/(1-t*z*x))
SI=z*x**2*(1-t*x+q**2*x**3)/((1-t*x)**2*(1-q*z*x**2))
SII=z**2*x**3*(1-q*x)/((1-t*x)*(1-t*z*x)*(1-q*z*x**2))
assert s.cancel(S-SI-SII)==0
# Both scalar coefficient rules (bounded, exact polynomial arithmetic)
for N in range(12):
 f=s.expand(s.series((1-t*x+q**2*x**3)/(1-t*x)**2,x,0,N+1).removeO()).coeff(x,N)
 r=t**N+(N-2)*q**2*t**(N-3) if N>=3 else t**N
 assert s.expand(f-r)==0,('F',N)
for J in range(12):
 f=s.expand(s.series((1-q*x)/(1-t*x),x,0,J+1).removeO()).coeff(x,J)
 assert s.expand(f-(1 if J==0 else t**(J-1)))==0,('J',J)
# Independent elementary-coefficient formulas used in the proof
for k in range(1,9):
 C=sum(q**r*t**(2*k-3-2*r) for r in range(k-1))
 for d in range(0,9):
  n=2*k+d
  E1=q**(k-1)*t**d+sum(q**r*t**(n-4-2*r) for r in range(k-1))
  if d>=3:E1+=(d-2)*q**(k+1)*t**(d-3)
  # From split SI and SII, each term assembled by extraction indices
  SIcoef=q**(k-1)*(t**d+((d-2)*q**2*t**(d-3) if d>=3 else 0))
  SIIcoef=sum(q**r*t**(k-2-r)*t**(k+d-2-r) for r in range(k-1))
  assert s.expand(E1-SIcoef-SIIcoef)==0,('E1',k,d)
  if d>=1:
   E2=t**(d-1)*(q**(k-1)+C)
   SIIother=q**(k-1)*t**(d-1)+sum(q**r*t**(n-4-2*r) for r in range(k-1))
   assert s.expand(E2-SIIother)==0,('E2',k,d)
print('EXTRACTION: symbolic GF split PASS; bounded coefficient rules and E1/E2 PASS')
