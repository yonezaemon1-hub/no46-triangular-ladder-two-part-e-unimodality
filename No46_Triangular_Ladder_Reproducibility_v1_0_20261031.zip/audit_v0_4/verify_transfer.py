#!/usr/bin/env python3
"""Symbolic transfer-matrix identity checks; NOT an independent colorings audit."""
import sympy as s
q,x,z=s.symbols('q x z')
t=1+q
M=s.Matrix([[t,0,0,0],[0,0,q,z],[q,z,0,0],[0,0,0,z*t]])
eab=s.Matrix([[0,1,0,0]])
I=z*x**2*(1-q*x)/(1-t*x)
transfer=s.factor(I*(eab*(s.eye(4)-x*M).inv()*s.ones(4,1))[0])
claimed=z*x**2*(1-q*x)/((1-t*x)*(1-q*z*x**2))*((1-x-q*x**2)/(1-t*x)+x*z/(1-t*z*x))
assert s.cancel(transfer-claimed)==0
# Closed D_k formula after [3]-multiplication (k=h+3):
#  [3] D_(h+3) = q^3 [h] t^(2h+4) + q^(h+3) t [h+3].
# Summing each term in h>=0 via geometric series yields closed_sum.
q3=1+q+q**2
closed_sum=(q**3*t**4*(t**2*z)/((1-t**2*z)*(1-q*t**2*z))
  + q**3*t/(1-q)*(1/(1-q*z)-q**3/(1-q**2*z)))/q3
positive_sum=q**3*t*(1+q*t*z)/((1-q*z)*(1-q**2*z)*(1-t**2*z)*(1-q*t**2*z))
assert s.cancel(closed_sum-positive_sum)==0
# Check C_k telescoping symbolically in the k-independent geometric sum form.
# Using variable r=q/t^2, t^2-q=[3]_q, so [3]*t^(2k-3)*(1-r^(k-1))/(1-r)
# equals t^(2k-1)-q^(k-1)*t.
assert s.expand(t**2-q-(1+q+q**2))==0
print('SYMBOLIC GF MATRIX IDENTITY: PASS')
print('CLOSED D_k GEOMETRIC SUM = POSITIVE GF: PASS')
print('GEOMETRIC DENOMINATOR: PASS')
print('Note: claims about s_k require combinatorial proof in PROOF_DRAFT.md.')
