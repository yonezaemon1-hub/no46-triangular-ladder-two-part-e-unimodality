#!/usr/bin/env python3
"""Fail-closed SHA256 manifest verification; verifies all files except manifest and self."""
import hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
lines=(p/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
expected={}
for ln in lines:
 if not ln.strip():continue
 digest,name=ln.split('  ',1)
 assert name not in expected and not ('/' in name or '\\' in name or name.startswith('.')), 'unsafe or duplicate file'
 expected[name]=digest
actual={f.name for f in p.iterdir() if f.is_file() and f.name not in ('SHA256SUMS.txt','check_hashes.py')}
assert actual==set(expected),f'manifest membership mismatch. missing={set(expected)-actual}, extra={actual-set(expected)}'
for name,d in expected.items():
 digest=hashlib.sha256((p/name).read_bytes()).hexdigest()
 assert d==digest, f'FAIL {name}: expected={d} actual={digest}'
print(f'SHA256: {len(expected)}/{len(expected)} PASS')
